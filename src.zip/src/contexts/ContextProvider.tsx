import React from 'react';
import ChangeStore from 'contexts/store/ChangeStore';

const ContextProvider = ({ children }: { children: React.ReactNode }) => {
  return <ChangeStore>{children}</ChangeStore>;
};

export default ContextProvider;
