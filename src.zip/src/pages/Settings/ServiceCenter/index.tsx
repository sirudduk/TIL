import ServiceContainer from 'pages/Settings/ServiceCenter/ServiceContainer';

export default ServiceContainer;
