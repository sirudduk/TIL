import QuestionCreateContainer from 'pages/Board/Qna/QnaCreate/QuestionCreateContainer';

export default QuestionCreateContainer;
