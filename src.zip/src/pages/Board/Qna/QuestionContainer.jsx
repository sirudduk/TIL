import React, { useContext, useCallback, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Store from 'contexts/store/store';

import { getQna, setCurrentBoard, setBoardKeyword } from 'store/board/reducer';
import NoticePresenter from 'pages/Board/NoticePresenter';
import { NOTICE_TYPE } from 'constants/text';

const QuestionContainer = () => {
  /** hooks */
  const { utils } = useContext(Store);
  const dispatch = useDispatch();

  /** state */
  const { qna, loading, tabIndex } = useSelector(state => state.board);
  const { currentStudioData } = useSelector(state => state.studio);
  const isLastNoti = useRef(false);
  const observer = useRef();

  /** func */
  const getInitData = useCallback(
    (title, isforce) => {
      if (qna.data.length && !title && !isforce) return;

      dispatch(getQna({ page: 1, limit: 20, all: 1, type: NOTICE_TYPE.qna, studio_id: currentStudioData.studio.id, title }));

      isLastNoti.current = false;
    },
    [dispatch, currentStudioData.studio.id, qna.data, tabIndex],
  );

  const getNewData = useCallback(async () => {
    if (qna.params.page <= qna.lastPage) {
      dispatch(getQna({ ...qna.params, studio_id: currentStudioData.studio.id }));
    } else {
      isLastNoti.current = true;
    }
  }, [dispatch, qna, currentStudioData.studio.id]);

  const lastElementRef = useCallback(
    node => {
      if (loading) return;
      if (observer.current) observer.current.disconnect();
      observer.current = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && !isLastNoti.current) {
          getNewData();
        }
      });
      if (node) observer.current.observe(node);
    },
    [loading, getNewData],
  );

  const getTime = useCallback(
    time => {
      return utils.getTime.getFullDateTime(time);
    },
    [utils.getTime],
  );

  const setDetailBoard = useCallback(data => dispatch(setCurrentBoard(data)), [dispatch]);

  const setKeyword = useCallback(data => dispatch(setBoardKeyword(data)), [dispatch]);

  return (
    <NoticePresenter
      getInitData={getInitData}
      noticeData={qna.data}
      lastElementRef={lastElementRef}
      isLastNoti={isLastNoti}
      getTime={getTime}
      setBoardKeyword={setKeyword}
      setCurrentBoard={setDetailBoard}
      type={qna.params}
    />
  );
};

export default QuestionContainer;
