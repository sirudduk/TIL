import DetailContainer from 'pages/Board/Detail/DetailContainer';

export default DetailContainer;
