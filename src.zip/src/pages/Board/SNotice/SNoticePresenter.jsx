import React, { useCallback, useContext, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import PullToRefresh from 'pulltorefreshjs';
import styled from 'styled-components';
import List from 'antd-mobile/lib/list';
import { useHistory } from 'react-router-dom';

import { LABEL, NOTICE_TYPE } from 'constants/text';
import Store from 'contexts/store/store';
import { theme } from 'assets/styles/theme';
import { ReactComponent as NotiUnread } from 'assets/icons/noti-unread.svg';

const { Item } = List;
const { Brief } = Item;

const SNoticePresenter = ({ getInitData, lastElementRef, getTime, noticeData, type, setCurrentSBoard }) => {

  /** state */
  const ptr = useRef();
  const { studio } = useSelector(state => state.studio.currentStudioData);

  /** hooks */
  const { utils } = useContext(Store);
  const visitTime = useRef(utils.getTime.localTime(new Date()));
  const history = useHistory();

  /** func */
  useEffect(() => {
    PullToRefresh.init({
      mainElement: `.${type.type}`,
      instructionsReleaseToRefresh: LABEL.pullRefresh,
      instructionsPullToRefresh: LABEL.pullRefresh,
      instructionsRefreshing: LABEL.refreshing,
      shouldPullToRefresh() {
        return !ptr.current.scrollTop
      },
      onRefresh() {
        getInitData(true);
      }
    });

    getInitData(true);

    return () => {
      localStorage.setItem(NOTICE_TYPE.snotice, visitTime.current);
      PullToRefresh.destroyAll();
    };

  }, [type.type]);

  const goToDetail = useCallback (
    data => {
      setCurrentSBoard({
        id: data.id,
        studio_id: studio.id,
        staff: data.created_by,
        title: data.title,
        type: NOTICE_TYPE.snotice,
        created: data.created_at,
        contents: data.context,
        attachments: [],
        comments: []
      });

      return history.push({ pathname: '/board-detail'});
    },
    [history, setCurrentSBoard, utils]
  );

  const SNoticeView = useCallback (
    () => 
      noticeData.map((notice, index) => {
        return (
          <NoticeViewList key={notice.id} ref={noticeData.length === index + 10 ? lastElementRef : null}>
            <List onClick={() => goToDetail(notice)}>
              <Item extra={notice.unRead ? <NotiUnread /> : undefined}>
                <Brief><div className='title'>{notice.title}</div></Brief>
                <Brief><div className='date'>{getTime(notice.created_at)}</div></Brief>
              </Item>
            </List>
          </NoticeViewList>
        );
      }),
      [getTime, lastElementRef, noticeData, type.type]
  );

  return (
    <SNoticeView />
  );
};

SNoticePresenter.propTypes = {
  getInitData: PropTypes.func,
  lastElementRef: PropTypes.func,
  getTime: PropTypes.func,
  noticeData: PropTypes.arrayOf(PropTypes.object),
  type: PropTypes.oneOfType([PropTypes.object]),
  setCurrentSBoard: PropTypes.func
};

SNoticePresenter.defaultProps = {
  getInitData: {},
  lastElementRef: {},
  getTime: {},
  noticeData: [],
  type: {},
  setCurrentSBoard: {}
};

const NoticeViewList = styled.div`
  .am-list-body .am-list-item .am-list-line .am-list-content {
    padding: 12px 0 16px 0;
  }
  .am-list-extra {
    position: absolute;
    top: 0;
    right: 16px;
  }
  .title {
    font-size: 14px;
    font-weight: 500;
    color: ${theme.color.black300};
    white-space: pre-wrap;
  }
  .dc-grid {
    display: grid;
    grid-template-rows: 1fr;
    grid-template-columns: 1fr auto;
    margin-top: 8px;
  }
  .date {
    font-size: 14px;
    font-weight: normal;
    color: ${theme.color.black500};
  }
  .comment {
    font-size: 14px;
    font-weight: normal;
    color: ${theme.color.black500};
  }
`;

export default SNoticePresenter;