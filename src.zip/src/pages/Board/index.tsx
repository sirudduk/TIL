import BoardContainer from 'pages/Board/BoardContainer';

export default BoardContainer;
