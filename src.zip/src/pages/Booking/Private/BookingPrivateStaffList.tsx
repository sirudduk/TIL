import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from 'store';
import List from 'antd-mobile/lib/list';
import styled from 'styled-components';

import { theme } from 'assets/styles/theme';
import MainLayout from 'components/MainLayout';
import Avatar from 'components/Avatar';
import { HEADER_TITLE } from 'constants/text';
import { _ } from 'utils/fx';
import getImageUrl from 'utils/getImageUrl';
import BookingActionPrivate from 'components/BookingAction/BookingActionPrivate';


const { Item } = List;
const { Brief } = Item; 

type LocationType = {
  state: { id: number; timeTableId: number };
};

export type staff = {
  avatar: { host: string; name: string; path: string };
  careers: { career: string; id: number }[];
  id: number;
  name: string;
};

type StaffType = {
  data: staff[];
  id: number;
  viewText: string | null;
};

const BookingPrivateStaffList = ({ location }: { location: LocationType }) => {
  const history = useHistory();
  const { loading, availablePrivateList } = useSelector((state: RootState) => state.booking);

    /** booking */
    const [booking, setBooking] = useState<any>({
      show: false,
      time: {},
      staff: {},
      id: Number
    });

  /** func */

  // 안드로이드 goback
  useEffect(() => {
    if (history.location.pathname === `/booking-private/${location.state.id}/staff-detail`) {
      setBooking({...booking, show: false });
    }
  }, [history.location.pathname, booking.show]);


  const goToBooking = (timeTable: StaffType, staff: staff) => {
    const time = _.omit(['data'], timeTable);
    setBooking({ show: true, time, staff, id: location.state.id });
    history.push(`/booking-private/${location.state.id}/staff-detail/#`, location.state);

    // return history.push({
    //   pathname: `/booking-private/${location.state.id}/course-detail`,
    //   state: { time, staff, id: location.state.id },
    // });
  };

  const StaffList: Function = () => {

    const res: StaffType = _.go(availablePrivateList.data, _.filter((_res: { id: number }) => _res.id === location.state.timeTableId))[0] || { data: [] };


    return res.data.map(el => (

      <ListStyle key={el.id} onClick={() => goToBooking(res, el)}>

        <div className='item'>

          {/* 날짜 */}
          <div className='date'>{res.viewText}</div>

          {/* 강사이름 */}
          <div className='user-info'>
            <Avatar
              className='user_img'
              size="small-2"
              imgUrl={getImageUrl(el?.avatar, '32x32')}
            />
            <span className='content'>{el.name} 강사</span>
          </div>
            

          {/* 룸 */}
          {/* {el.room && <Brief style={{ whiteSpace: 'pre-wrap' }}>{el.room.name} 룸} */}

        </div>

      </ListStyle>
    ));
  };

  return (
    <MainLayout header={{ title: HEADER_TITLE.privateBooking, titleNormal: true, backFunc: history.goBack }} scroll loading={loading}>
      <StaffList style={{ overflowY: 'auto' }} />

      <BookingActionPrivate 
        show={booking.show}
        time={booking.time}
        staff={booking.staff}
        id={booking.id}
        onRequestClose={() => { setBooking({...booking, show: false }); history.goBack(); }} />
        
    </MainLayout>
  );
};

const ListStyle = styled.div`
  .date {
    font-size: 18px;
    font-weight: 500;
    color: ${theme.color.black300};
    margin-bottom: 8px;
  }
  .content {
    font-size: 14px;
    font-weight: normal;
    color: ${theme.color.black500};
  }
  .user-info {
    display: flex;
    align-items: center;
  }
  .user_img {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    margin-right: 8px;
    color: #555;
    font-size: 14px;
  }
  .item {
    margin: 12px 16px;
    margin-bottom: 24px;
    border-radius: 16px;
    box-shadow: 2px 2px 4px 2px rgba(0, 0, 0, 0.1);
    padding: 12px;
    height: 146px;

    display: flex;
    flex-direction: column;
    justify-content: center;
  }
`;

export default BookingPrivateStaffList;
