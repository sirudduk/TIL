import React from 'react';

export type passwordProps = {
  validation_id: null | string;
  validation_code: null | string;
  user_account: {
    password: null | string;
  };
  user_id: null | string;
  step: number;
};

export type textProps = {
  smsValid: boolean;
  email: string;
  mobile: string;
  validateCode: string;
  isClickValidButton: boolean;
  password: string;
  confirmPassword: string;
};

export type validType = {
  email: boolean;
  mobile: boolean;
  validateCode: boolean;
  password: boolean;
  confirmPassword: boolean;
};

export type stopOnePresenterProps = {
  smsValid: boolean;
  goToNextStep: () => void;
  email: string;
  mobile: string;
  validateCode: string;
  valid: validType;
  isClickValidButton: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement> | { target: { value: string; name: string } }) => void;
  onSubmit: () => void;
  confirmSmsCode: () => void;
};

export type stepTwoPresenterProps = {
  text: textProps;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  valid: validType;
  changePassword: () => void;
};
