import FindPasswordContainer from 'pages/FindPassword/FindPasswordContainer';

export default FindPasswordContainer;
