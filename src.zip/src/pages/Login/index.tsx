import LoginContainer from 'pages/Login/LoginContainer';

export default LoginContainer;
