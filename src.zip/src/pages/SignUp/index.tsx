import SignUpContainer from 'pages/SignUp/SignUpContainer';

export default SignUpContainer;
