export type signupType = {
  step: number;
  user_account: {
    email: null | string;
    mobile: null | string;
    password: null | string;
    name: null | string;
  };
  validation_id: null | string;
  validation_code: null | string;
};

export type signUpOneType = {
  signUpData: signupType;
  setSignUpData: any;
  checked: { [key: string]: boolean };
  onCheckBox: (target: string) => void;
};

type textType = {
  mobile: string;
  validateCode: string;
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
};

type validType = {
  mobile: boolean;
  validateCode: boolean;
  name: boolean;
  email: boolean;
  password: boolean;
  confirmPassword: boolean;
};

export type SignUpTwoType = {
  text: textType;
  valid: validType;
  isClickValied: boolean;
  loading: boolean;
  onChange: (e: any) => void;
  sendValidCode: () => void;
  setValidCode: (e: any) => void;
  checkCode: () => void;
  onSignUp: () => void;
  checkEmail: () => void;
  signUpData: signupType;
  setSignUpData: any;
  disabled: boolean;
};
