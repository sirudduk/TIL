import EditAccount from 'pages/MyPage/EditAccount/EditAccountContainer';

export default EditAccount;
