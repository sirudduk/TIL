import MyPageContainer from 'pages/MyPage/MyPageContainer';

export default MyPageContainer;