import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useSelector, shallowEqual, useDispatch } from 'react-redux';
import { setStudio, setTicket, setTabIndex, getUserTicket } from 'store/studio/reducer';

import { RootState } from 'store';
import { studioProps, ticketProps, ticketRawType } from 'store/studio/types';
import SelectStudioPresenter from 'pages/SelectStudio/SelectStudioPresenter';

type locationProps = {
  location?: { state?: { tabIndex: number } };
};

const SelectStudioContainer = ({ location }: locationProps) => {
  /** hook */
  const history = useHistory();
  const dispatch = useDispatch();

  /** state */
  const { data, currentStudioData, loading, tabIndex } = useSelector((state: RootState) => state.studio, shallowEqual);

  /** func */

  // useEffect(() => {
  //   const studioId = localStorage.getItem('studio_id');
  //   if (studioId) {
  //     data.map(({ studio }) => (studio.id === Number(studioId) ? dispatch(setStudio(studio)) : null));
  //   }
  // }, [data, dispatch]);

  useEffect(() => {
    // 수강권 선택시 현재 스튜디오 id 비교 => 시설에서 수강권으로 바로
    // if (data.length !== 0) {
    //   data.map(({ studio }) => {
    //     if (currentStudioData.studio.id === studio.id) dispatch(setTabIndex(1));
    //     else dispatch(setTabIndex(0));
    //   });
    // }

    // dispatch(setTabIndex(location?.state?.tabIndex ? location?.state.tabIndex : 0)); // 하단바 메뉴 - 수강권 - 수강권 선택
    dispatch(getUserTicket());
    // eslint-disable-next-line
  }, []);

  const onSetStudioOnly = (studio: studioProps) => {
    dispatch(setStudio(studio));
  };

  const onSetStudio = (studio: studioProps) => {
    dispatch(setStudio(studio));
    dispatch(setTabIndex(1));
  };

  const setTickets = (ticket: ticketProps, ticketRaw: ticketRawType, path: string) => {
    dispatch(setTicket(ticket, ticketRaw));
    localStorage.setItem('studio_id', String(currentStudioData.studio.id));
    return history.push(path);
  };

  return (
    <SelectStudioPresenter
      companies={data}
      loading={loading}
      currentStudioData={currentStudioData}
      setStudio={(studio: studioProps) => onSetStudio(studio)}
      setStudioOnly={(studio: studioProps) => onSetStudioOnly(studio)}
      setTicket={(ticket: ticketProps, ticketRaw: ticketRawType, path: string) => setTickets(ticket, ticketRaw, path)}
      tabIndex={tabIndex}
      backToSelectStudio={() => dispatch(setTabIndex(0))}
        />
  );
};

export default SelectStudioContainer;
