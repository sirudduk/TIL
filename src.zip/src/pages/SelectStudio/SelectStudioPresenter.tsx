import React from 'react';
import SelectStudio from 'components/SelectStudio';
import SelectTicket from 'components/SelectTicket';
import { selectStudioPresenterProps } from './type';

const SelectStudioPresenter = ({
  companies,
  setStudio,
  currentStudioData,
  backToSelectStudio,
  setTicket,
  tabIndex,
  loading,
  setStudioOnly
}: selectStudioPresenterProps) => {

  return (
    <>
      {!tabIndex ? (
        <SelectStudio 
          companies={companies} 
          currentStudioData={currentStudioData} 
          loading={loading} 
          setStudio={setStudio}
          setStudioOnly={setStudioOnly}
           />
      ) : (
        <SelectTicket
          companies={companies}
          currentStudioData={currentStudioData} 
          backToSelectStudio={backToSelectStudio}
          loading={loading}
          setTicket={setTicket}
          setStudioOnly={setStudioOnly}
        />
      )}
    </>
  );
};

export default SelectStudioPresenter;
