import { studioProps, ticketProps, ticketRawType } from 'store/studio/types';

export type selectStudioPresenterProps = {
  setStudio: (studio: studioProps) => void;
  setStudioOnly: (studio: studioProps) => void;
  loading: boolean;
  tabIndex: number;
  backToSelectStudio: () => void;
  setTicket: (ticket: ticketProps, ticketRaw: ticketRawType, path: string) => void;
  currentStudioData: { studio: { id: number, name: string } };
  companies: { studio: studioProps; ticketCardData: ticketProps[]; ticket: { [key: string]: ticketRawType } }[];
};

export type selectTicketProps = {
  backToSelectStudio: () => void;
  setTicket: (ticket: ticketProps, ticketRaw: ticketRawType, path: string) => void;
  setStudioOnly: (studio: studioProps) => void;
  loading: boolean;
  currentStudioData: { studio: { id: number, name: string } };
  companies: { studio: studioProps; ticketCardData: ticketProps[]; ticket: { [key: string]: ticketRawType } }[];
  location?: { state: string };
};

export type selectStudioProps = Omit<selectStudioPresenterProps, 'tabIndex' | 'backToSelectStudio' | 'setTicket'>;
