import SelectStudioContainer from 'pages/SelectStudio/SelectStudioContainer';

export default SelectStudioContainer;
