import NotificationContainer from 'pages/Notification/NotificationContainer';

export default NotificationContainer;
