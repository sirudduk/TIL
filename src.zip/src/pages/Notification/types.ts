export type notiParamsProps = {
  limit: number;
  min_id: number | null;
};

export type notiDetailProps = {
  course_type: string;
  created_at: string;
  id: number;
  message: string;
  ref_type: string;
  staff_image: null | string[];
  staff_name: string;
  studio_image: null | string[];
  studio_name: string;
  title: string;
  type: string;
};

export type notificationPresenterProps = {
  getInitNoti: () => void;
  notiData: notiDetailProps[];
  convertLocalTime: (value: string, type: string | null) => string;
  goToDetail: (data?: notiDetailProps) => void;
  checkNoReadNoti: (createTime: string) => boolean;
  loading: boolean;
  lastElementRef: (node: any) => void;
};
