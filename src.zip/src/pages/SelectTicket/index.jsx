import SelectTicketContainer from 'pages/SelectTicket/SelectTicketContainer';

export default SelectTicketContainer;
