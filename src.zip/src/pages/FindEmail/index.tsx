import FindEmailContainer from 'pages/FindEmail/FindEmailContainer';

export default FindEmailContainer;
