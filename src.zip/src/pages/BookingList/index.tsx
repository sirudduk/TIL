import BookingListContainer from 'pages/BookingList/BookingListContainer';

export default BookingListContainer;
