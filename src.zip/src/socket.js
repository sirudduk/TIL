import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Echo from 'laravel-echo';
import io from 'socket.io-client';
import * as serviceWorker from './serviceWorker';
window.io = io;
const echo = new Echo({
  broadcaster: 'socket.io',
  host: window.location.hostname + ':6001',
});
echo
  .channel('user_api_database_user-event')
  .listen('UserBooking', e => {
    console.log(e);
  })
  .listen('UserEvent', e => {
    console.log(e);
  });
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
);
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
