import dayjs from 'dayjs';

/**
 * 날짜 차이 계산
 *
 * @param {Date} from
 */
export default (to, from = dayjs(), type = 'day') => {
  from = dayjs(from).startOf('day');
  return dayjs(to)
    .startOf('day')
    .diff(from, type === 'day' ? 'days' : 'months');
};
