import moment from 'moment';
import filters from 'utils/filters';

type WorkingHoursType = {
  start_time: string;
  end_time: string;
};

type staffListType = {
  working_hours: WorkingHoursType;
  events: WorkingHoursType[];
};

type timeTableType = {
  id: number;
  startTime: string;
  endTime: string;
  viewText: string;
  data: staffListType[];
};

export default (interval: number | undefined, selectDate: string | Date, classPeriod: number | undefined, staffList: staffListType[]) => {
  const timeTable: timeTableType[] = [];
  const interVal = interval === 30 ? 47 : 23;
  
  for (let i = 0; i <= interVal; i++) {
    let startTime = '';
    if (interval === 30) {
      startTime = moment(selectDate)
        .hours(Math.floor(i / 2))
        .minutes(i % 2 ? 30 : 0)
        .second(0)
        .format('YYYY-MM-DD HH:mm:ss');
    } else {
      startTime = moment(selectDate).hours(i).minutes(0).second(0).format('YYYY-MM-DD HH:mm:ss');
    }
    const endTime = moment(startTime).add(classPeriod, 'm').format('YYYY-MM-DD HH:mm:ss');
    const viewText = filters.dateLecture(startTime, endTime);

    timeTable.push({ id: interval === 30 ? i : i * 2, startTime, endTime, viewText, data: [] });
  }

  for (let i = 0; i < staffList.length; i++) {
    timeTable.forEach(el => {
      if (!staffList[i].working_hours) return;
      // 강사 근무시간 이외 시간 제외
      if (
        moment(staffList[i].working_hours.start_time) <= moment(el.startTime) &&
        moment(staffList[i].working_hours.end_time) >= moment(el.endTime)
      ) {
        let result = true;
        for (let j = 0; j < staffList[i].events.length; j++) {
          // 강사 휴식 or 예약 있으면 제외
          if (
            moment(el.startTime).add(1, 'm').isBetween(staffList[i].events[j].start_time, staffList[i].events[j].end_time, null, '[]') ||
            moment(el.endTime).isBetween(staffList[i].events[j].start_time, staffList[i].events[j].end_time, null, '[]')
          ) {
            return (result = false);
          }
        }
        if (result) {
          // 검색일이 오늘이면 현재 시간보다 이전 수업 시작시간을 가진 수업은 제외
          if (moment(selectDate).format('YYYY-MM-DD') === moment().format('YYYY-MM-DD')) {
            if (moment() < moment(el.startTime)) el.data.push(staffList[i]);
          } else {
            el.data.push(staffList[i]);
          }
        }
      }
    });
  }
  return timeTable.filter(({ data }) => data.length);
};
