import Toast from 'antd-mobile/lib/toast';

export default loading => (loading ? Toast.loading('Loading', 50000) : Toast.hide());
