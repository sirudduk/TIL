import getDaysDiff from './getDaysDiff';

export default holdings => {
  if (!holdings || !holdings.length) return null;

  const { start_on, end_on } = holdings[holdings.length - 1];
  const period = getDaysDiff(end_on, start_on) + 1;
  return `${period}일 정지`;
};
