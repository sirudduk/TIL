import React from 'react';
import ReactDOM from 'react-dom';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import logger from 'redux-logger';
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import createSagaMiddleware from 'redux-saga';
import { composeWithDevTools } from 'redux-devtools-extension';
import * as mobiscroll from '@mobiscroll/react';
import 'assets/styles/global-mobiscroll.scss';
import 'antd-mobile/dist/antd-mobile.css';
import moment from 'moment';
import 'moment/locale/ko';
import dayjs from 'dayjs';
import 'dayjs/locale/ko';
import GlobalStyle from 'assets/styles/global-styles.ts';
import ContextProvider from 'contexts/ContextProvider';
import Routes from 'pages/Routes';
import rootReducer from 'store';
import rootSaga from 'store/rootSaga';
import { CookiesProvider } from 'react-cookie';
import axios from 'api/axios';
import { logout } from 'store/auth/actions';
import ReactDOMServer from 'react-dom/server';

dayjs.locale('ko');

mobiscroll.settings = {
  lang: 'ko',
  theme: 'ios',
  themeVariant: 'light',
  okText: '확인',
  cancelText: '취소',
};

const errorInfo = {
  count: 0,
  isTokenRefreshing: false,
  isError: false,
  reset: () => {
    errorInfo.count = 0;
  },
  counting: () => {
    errorInfo.count++;
  },
};

window.alert = mobiscroll.alert;
window.mobilsConfirm = mobiscroll.confirm;

/** store */
moment.locale('ko');
const sagaMiddleware = createSagaMiddleware();
// const enhancer =
//   process.env.NODE_ENV === 'production' ? compose(applyMiddleware(sagaMiddleware)) : composeWithDevTools(applyMiddleware(sagaMiddleware, logger));
const enhancer = composeWithDevTools(applyMiddleware(sagaMiddleware, logger));

export const store = createStore(rootReducer, enhancer);

const persistor = persistStore(store);

sagaMiddleware.run(rootSaga);

const UNAUTHORIZED = 401;

const { dispatch } = store; // direct access to redux store.

const errorMessage = (
  <div style={{ lineHeight: '1.5' }}>
    시설 정보를 불러올 수 없습니다.
    <br />
    기기종류 별로 아래와 같이 조치 후 <br /> 로그인해주세요. <br />
    <br />
    [아이폰 사용자]
    <br />
    - 앱을 삭제후 재설치 해주세요.
    <br /> <br />
    [안드로이드 사용자]
    <br />
    - 아래처럼 데이터 삭제해 주시기 바랍니다.
    <br />
    * 모바일 자체 설정 &#8594; 애플리케이션 &#8594; <br /> Studiomate 검색 및 선택 &#8594; 저장공간 &#8594; 데이터 삭제 *
  </div>
);

axios.interceptors.response.use(
  response => response,
  async error => {
    if (error.code === 'ECONNABORTED') {
      alert({
        message: '이용자가 많아 처리가 지연되고 있습니다. 잠시후 다시 시도해주세요.',
      });
      return;
    }

    if (!errorInfo.count && error?.response?.data?.message === 'Unauthenticated.') {
      errorInfo.counting();
      switch (error?.response?.status) {
        case UNAUTHORIZED:
          alert({
            message: ReactDOMServer.renderToStaticMarkup(errorMessage),
            callback: () => {
              dispatch(logout());
            },
          });
          break;
        default:
          alert({ message: '서버와의 통신에 실패 하였습니다. \n 앱을 재 실행 해 주세요.' });
          break;
      }
    }
    if (errorInfo.count && !errorInfo.isError) {
      errorInfo.isError = true;
      setTimeout(() => {
        errorInfo.isError = false;
        errorInfo.reset();
      }, 1000);
    }
    return Promise.reject(error);
  },
);

ReactDOM.render(
  <Provider store={store}>
    <PersistGate persistor={persistor}>
      <CookiesProvider>
        <ContextProvider>
          <GlobalStyle />
          <Routes />
        </ContextProvider>
      </CookiesProvider>
    </PersistGate>
  </Provider>,
  document.getElementById('root'),
);
