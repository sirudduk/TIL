import { useState, useEffect } from 'react';
import axios from 'axios';

/**
 * example
 *
 * import useAxios from 'hooks/useAxios';
 * const {loading, data, err, refatch} = useAxios({ url: 'https:~~~' })
 *
 *  <button onClick={refatch}>refatch</button>
 */

export default (opts, axiosInstance = axios) => {
  const [state, setState] = useState({
    loading: true,
    err: null,
    data: null,
  });

  const [trigger, setTrigger] = useState(0);

  if (!opts.url) return;

  const refatch = () => {
    setState({ ...state, loading: true });
    setTrigger(Date.now());
  };

  useEffect(() => {
    axiosInstance(opts)
      .then(data => {
        setState({ ...state, loading: false, data, err: null });
      })
      .catch(err => {
        setState({ ...state, loading: false, err, data: null });
      });
  }, [trigger]);

  return { ...state, refatch };
};
