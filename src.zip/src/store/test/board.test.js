// import { initialState, board } from '../board';

// describe('board reducer initalState test', () => {
//   it('initalState test', () => {
//     expect(initialState).toHaveProperty('tabIndex');
//     expect(initialState).toHaveProperty('boardList');
//     expect(initialState).toHaveProperty('currentBoard');
//   });

//   describe('board action funcion test', () => {
//     it('board reducer action test', () => {
//       const changeTabIndex = {
//         type: 'BOARD/CHANGE_TAB',
//         data: '2',
//       };

//       expect(board(initialState.user, changeTabIndex).tabIndex).toEqual('2');
//     });

//     it('notice request test', () => {
//       const getNotice = {
//         type: 'BOARD/GET_NOTICE_REQUEST',
//         params: { title: '' },
//       };

//       expect(board(initialState, getNotice).loading).toEqual(true);
//       expect(board(initialState, getNotice).notice.params.title).toEqual('');
//     });

//     it('notice success test', () => {
//       const getNotice = {
//         type: 'BOARD/GET_NOTICE_SUCCESS',
//         data: { data: [{ id: 1 }, { id: 2 }], meta: { current_page: 1, last_page: 10 } },
//       };

//       expect(board(initialState, getNotice).notice).toEqual({
//         params: { page: 2, limit: 20, all: 1, type: 'notice', title: '' },
//         lastPage: 10,
//         data: [{ id: 1 }, { id: 2 }],
//       });

//       getNotice.data.meta.current_page = 2;
//       const get = board(initialState, getNotice);
//       expect(board(get, getNotice).notice.params.page).toEqual(3);
//     });

//     it('set board keyword test', () => {
//       const setKeyword = {
//         type: 'SET_BOARD_KEYWORD',
//         data: {
//           keyword: 'hahaha',
//           type: 'notice',
//         },
//       };

//       expect(board(initialState, setKeyword).notice.params.title).toEqual('hahaha');

//       setKeyword.data.type = 'qna';
//       expect(board(initialState, setKeyword).qna.params.title).toEqual('hahaha');
//       expect(board(initialState, setKeyword).notice.params.title).toEqual('');
//     });
//   });
// });
