// import { GET_USER_TICKET_REQUEST, GET_USER_TICKET_SUCCESS, SET_STUDIO, SET_TICKET } from 'constants/actionTypes';
// import { initalState, studio } from '../studio/studioStore';

// describe('userTicket reducer initalState test', () => {
//   it('initalState test', () => {
//     expect(initalState).toHaveProperty('userTicket');
//     expect(initalState).toHaveProperty('loading');
//     expect(initalState).toHaveProperty('currentStudioData');
//   });

//   describe('request userTicket action test', () => {
//     it('userTicket reducer action test', () => {
//       const getUserTicket = {
//         type: GET_USER_TICKET_REQUEST,
//       };

//       expect(studio(initalState, getUserTicket).loading).toEqual(true);
//     });

//     it('get userTicket action test', () => {
//       const successUserTicket = {
//         type: GET_USER_TICKET_SUCCESS,
//         data: [
//           { id: 123, studio_id: 8 },
//           { id: 456, studio_id: 9 },
//         ],
//       };

//       expect(studio(initalState, successUserTicket).userTicket).toEqual([
//         { id: 123, studio_id: 8 },
//         { id: 456, studio_id: 9 },
//       ]);
//     });

//     it('select studio/ticket action test', () => {
//       const selectStudio = {
//         type: SET_STUDIO,
//         studio: {
//           id: 848,
//           name: 'nkh',
//           subdomain: 'studiomate',
//           point: 0,
//           expire_on: '2030-01-01',
//           grade: 2,
//           disabled: false,
//         },
//       };

//       const selectTicket = {
//         type: SET_TICKET,
//         ticket: {
//           id: 22222,
//           studio_id: 8,
//           ticket_id: 272,
//           max_coupon: 50,
//         },
//       };

//       expect(studio(initalState, selectStudio).currentStudioData).toEqual({ studio: selectStudio.studio, ticket: {} });
//       expect(studio(initalState, selectTicket).currentStudioData).toEqual({ studio: {}, ticket: selectTicket.ticket });
//     });
//   });
// });
