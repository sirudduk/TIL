// import { initialState, auth } from '../auth';

// describe('auth reducer initalState test', () => {
//   it('initalState test', () => {
//     expect(initialState).toHaveProperty('accessToken');
//     expect(initialState).toHaveProperty('expiredIn');
//     expect(initialState).toHaveProperty('user');
//   });

//   describe('auth action funcion test', () => {
//     it('auth reducer action test', () => {
//       const setAccessTokenAction = {
//         type: 'SET_ACCESS_TOKEN',
//         data: {
//           access_token: 'token',
//           fcmToken: 'fcmToken',
//           user_account: { id: 123, name: 'nkh' },
//         },
//       };

//       expect(auth(initialState.user, setAccessTokenAction)).toEqual({
//         accessToken: 'token',
//         user: { id: 123, name: 'nkh' },
//         fcmToken: 'fcmToken',
//       });

//       const setDeleteTokenAction = {
//         type: 'DELETE_TOKEN',
//       };

//       expect(auth(initialState.user, setDeleteTokenAction)).toEqual({
//         accessToken: null,
//         user: null,
//         expired_in: null,
//       });
//     });
//   });
// });
