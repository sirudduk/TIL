export const NOTI_ENROLL_TICKET = 'NOTI_ENROLL_TICKET' as const;

export type INotiState = {
  enrollBooking: boolean;
};
