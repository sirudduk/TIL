import { NOTI_ENROLL_TICKET } from './types';

export const notiEnrollTicket = (payload: boolean) => ({ type: NOTI_ENROLL_TICKET, payload });
export type ActionRequest = ReturnType<typeof notiEnrollTicket>;
//   | ReturnType<typeof getAvailableBookingList>
