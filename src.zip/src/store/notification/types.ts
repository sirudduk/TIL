export const GET_NOTIFICATION_SUCCESS = 'GET_NOTIFICATION_SUCCESS' as const;
export const GET_NOTIFICATION_FAIL = 'GET_NOTIFICATION_FAIL' as const;
export const GET_NOTIFICATION_REQUEST = 'GET_NOTIFICATION_REQUEST' as const;

export type NotificationState = {
  notiList: Array<object>,
  params: {
    min_id?: null | number,
    limit: number
  },
  loading: boolean,
};