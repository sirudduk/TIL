/* eslint-disable array-callback-return */
import produce from 'immer';
import {
  GET_NOTIFICATION_REQUEST,
  GET_NOTIFICATION_SUCCESS,
  GET_NOTIFICATION_FAIL,
  NotificationState
} from './types';

import { ActionRequest } from './actions';

export const initialState: NotificationState = {
  notiList: [],
  params: {
    min_id: null,
    limit: 10
  },
  loading: false,
};

export const notification = (state = initialState, action: ActionRequest) =>
  produce(state, draft => {
    switch (action.type) {
      case GET_NOTIFICATION_REQUEST:
        draft.loading = true;
        break;
      case GET_NOTIFICATION_SUCCESS:
        draft.notiList = [...state.notiList, ...action.payload];
        draft.params.min_id = action.payload[action.payload.length - 1].id
        draft.loading = false;
        break;
      case GET_NOTIFICATION_FAIL:
        draft.loading = false;
        break;
    }
  });

export default notification;
