import { all, fork, put, call, takeLatest } from 'redux-saga/effects';
import notification from 'api/modules/notification';
import { GET_NOTIFICATION_REQUEST } from './types';

import {
  getNotificationSuccess,
  getNotificationFail
} from './actions';

function* getNotificationSaga(action) {
  try {
    const result = yield call(() => notification.getNotice(action.params));
    yield put(getNotificationSuccess(result.data.user_notices));
  } catch (err) {
    yield put(getNotificationFail(err?.response?.data));
  }
}

function* watchGetNotification() {
  yield takeLatest(GET_NOTIFICATION_REQUEST, getNotificationSaga)
}

export default function* notificationSaga() {
  yield all([
    fork(watchGetNotification),
  ]);
}
