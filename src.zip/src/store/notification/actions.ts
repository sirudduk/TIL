/* eslint-disable no-undef */
import {
  GET_NOTIFICATION_REQUEST,
  GET_NOTIFICATION_SUCCESS,
  GET_NOTIFICATION_FAIL
} from './types';

export const getNotificationRequest = (params: any) => ({ type: GET_NOTIFICATION_REQUEST, params });
export const getNotificationSuccess = (payload: any) => ({ type: GET_NOTIFICATION_SUCCESS, payload });
// 에러 확인
export const getNotificationFail = (error: any) => ({ type: GET_NOTIFICATION_FAIL, error });

export type ActionRequest = 
  | ReturnType<typeof getNotificationRequest>
  | ReturnType<typeof getNotificationSuccess>
  | ReturnType<typeof getNotificationFail>;


