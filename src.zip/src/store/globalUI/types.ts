export const OPEN_MENU = 'global/OPEN_MENU' as const;
export const CLOSE_MENU = 'global/CLOSE_MENU' as const;
export const OPEN_NOTI_MODAL = 'global/OPEN_NOTI_MODAL' as const;
export const CLOSE_NOTI_MODAL = 'global/CLOSE_NOTI_MODAL' as const;

export type globalUITypes = {
  isMenuShow: boolean;
};