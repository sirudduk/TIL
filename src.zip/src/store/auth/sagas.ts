import { all, fork, put, call, takeLatest } from 'redux-saga/effects';
import auth from 'api/modules/auth';
import { AxiosResponse } from 'axios';
import { GET_ACCOUNT_REQUEST, getAccountRes, DELETE_TOKEN, KEEP_ACCESS_TOKEN } from 'store/auth/types';
import { setAuthHeaders, getUserAccountSuccess, getUserAccountFailure, getUserAccount } from 'store/auth/actions';
import localStorage from 'utils/localStorage';

function* deleteTokenSaga() {
  yield call(() => auth.patchFCMToken({ instance_token: 'THIS_TOKEN_IS_NOT_USED' }));
}

function* watchDeleteToken() {
  yield takeLatest(DELETE_TOKEN, deleteTokenSaga);
}

function* keepAccessTokenSaga({ payload }: any) {
  try {
    yield call(() => localStorage.asyncSet('access_token', payload.data));
    yield call(() => setAuthHeaders(localStorage.get('access_token')));
    yield put(getUserAccount());
  } catch(error) {
    alert({ message: error });
  }
}

function* watchkeepAccessToken() {
  yield takeLatest(KEEP_ACCESS_TOKEN, keepAccessTokenSaga);
}

function* getUserAccountSaga() {
  try {
    // yield alert({ message: `why ${localStorage.get('access_token')}` });
    const result: AxiosResponse<getAccountRes> = yield call(auth.getAccount);
    yield put(getUserAccountSuccess(result.data.user_account));
  } catch (err) {
    // yield alert({ message: err });
    yield put(getUserAccountFailure());
  }
}

function* watchGetUserAccount() {
  yield takeLatest(GET_ACCOUNT_REQUEST, getUserAccountSaga);
}

export default function* authSaga() {
  yield all([fork(watchGetUserAccount), fork(watchDeleteToken), fork(watchkeepAccessToken)]);
}
