import 'styled-components';

declare module 'styled-components' {
  export interface DefaultTheme {
    basicWidth: string;

    color: {
      main: string;
      sub: string;
      black500: string;
      black300: string;
      greyBBB: string;
      greyCCC: string;
      greyDDD: string;
      red: string;
      blue: string;
      deepSkyBlue: string;
      lightPurple: string;
      pink: string;
      black000: string;
      black4d: string;
      lightGray: string;
      newGray: string;
      newBlue: string;
    };

    fonts: {
      font10: string;
      font12: string;
      font14: string;
      font18: string;
    };

    margins: {
      pageBasicMargins: string;
      t8: string;
    };

    displays: {
      inlineBlock: string;
    };

    flexBox: {
      displayFlex: string;
      flexDirection: function;
      flexAlign: function;
      flexJustify: function;
    };

    tagColor: {
      blue: string;
      cyan: string;
      red: string;
      orange: string;
      lightPurple: string;
      magenta: string;
      black: string;
      teal: string;
      darkGrey: string;
    };

  }
}
