declare interface Window {
  ReactNativeWebView: any;
  mobilsConfirm: any;
}
