import axios from '../axios';

const BASE_URL = '/member/user';

export default {
  getNotice: (params: { limit: number }) => axios.get(`${BASE_URL}/notice`, { params }),
};
