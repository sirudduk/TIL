import modules from './modules/index';

export default {
  ...modules,
};
