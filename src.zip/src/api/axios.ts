/* eslint-disable func-names */
/* eslint-disable dot-notation */
import axios from 'axios';
import qs from 'qs';
import localStorage from 'utils/localStorage';
// import { isMobile } from 'react-device-detect';

const headers = {
  ...axios.defaults.headers,
  Authorization: `Bearer ${localStorage.get('access_token')}`,
  // Authorization: `Bearer 1231312`,
  'Cache-control': 'no-cache',
  'Content-Encoding': 'gzip',
  'web-version': process.env.REACT_APP_VERSION,
};

const paramsSerializer = (params: any) => {
  return qs.stringify(params, {
    arrayFormat: 'brackets',
    encodeValuesOnly: true,
    skipNulls: true,
  });
};

const instance = axios.create({
  baseURL: process.env.REACT_APP_API_BASE_URL,
  headers,
  paramsSerializer,
  timeout: 5000,
});

instance.interceptors.request.use(async (config: any) => {
  // if (process.env.REACT_APP_ENV === 'production' && !isMobile && window.location.pathname !== '/login') {
  //   localStorage.remove();
  //   return config
  // }
  return config;
});

export default instance;
