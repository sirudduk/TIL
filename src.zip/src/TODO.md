## TS 변환 과정 (1순위)

<!-- - private 예약시간 policy 값 기반 filter 추가 -->

- board store 변환 -> board 관련 page 변환
- observation scroll -> type뭔지 확인 -> 일단 any

* 푸시 ios ㅜㅜㅜ

- 수강권 리스트 - 이전 내역 (환불, 이용만료) 버튼 (노확정)
- 예약 내역 달력 추가 - 예약내역 날짜로 가져오기 달별로, 가져온 후, 일별로 필터 하고 날짜에 예약있으면 마크
- push message ref_type 없음
- back noti - notification 상세정보로 redi -> noti 상세보기 api 필요 - ref_id를 기준으로 가져옴

## todos

- push 알림오면 디테일로 이동할때, push 값 형태 체크(백엔드에 요청해야함)
  - 알림
  - 문의
  - 수강권 (추가/환불)
  - 예약 (예약/취소)
- 회원가입 > 이메일 중복 체크 (백엔드 api - postman > studio apis > public > account > 이메일중복검사 ({{API_DOMAIN}}/public/account/email-duplicate?email=adasda@naver.com) ---> return 값은 해당 이메일이 이미 존재하는 갯수. 따라서 1이상이면 중복으로 처리하면 됨)
- 이미지 불러올때까지 로딩 띄우기(better to do)
- 수강권 색깔 추가
- 마감된 수업 구분(sm-449) 처리된건지 확인 필요

## done

- verfication number input 모듈화
- 맨 처음 userTicket 가져올 때, studio의 disable정보 true면 filtering
- calendar
  - 주/월/오늘 아이콘 삽입
  - 날짜별 캘린더 타이틀 변경
- 캘린더 정지기간 color type 문의사항 확인 - any로 처리 문의 확인완료 (9/11)

- 예약 버튼 조건
  - 패밀리일경우 예약했어도 예약 버튼, 예약 대기 버튼 나와야됨, 결석일때는 버튼 없음 동일
  1. 예약 - 예약 가능 시간 이내, max_trainee 안참
  2. 취소 - 예약 , 예약 확정시 버튼 활성화 -> 취소 가능시간 이내면, 취소모달 아니면, 까인다는 모달
  3. 예약 대기 - 수업 종료 안되고, 사람 꽉차거나, 예약 가능 시간 이후 이면
  4. 예약 대기 취소 - 현재 예약 대기 status 이면
  5. 출석완료 - 버튼 없음
  6. 예약마감 - 예약대기버튼
  7. 예약완료 - 예약취소버튼
  8. 수업종료 - 버튼 없음

## socket

- src/socket.js 파일 참조
