import React from 'react';

function NoMatch() {
  return <div className="div">404 not found</div>;
}

export default NoMatch;
