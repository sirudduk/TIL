/* eslint-disable react/prop-types */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import '../BookingAction/bookingActionStyle.scss';
import React from 'react';
import styled from 'styled-components';
import List from 'antd-mobile/lib/list';

import { ReactComponent as Close } from 'assets/icons/icon-24-close-white.svg';
import { ReactComponent as Address } from 'assets/icons/icon-24-address.svg';
import { ReactComponent as Phone } from 'assets/icons/icon-24-phone.svg';
import { ReactComponent as Schedule } from 'assets/icons/icon-24-schedule.svg';
import { ReactComponent as Call } from 'assets/icons/button-phonecall.svg';
import { ReactComponent as Studio } from 'assets/icons/studio.svg';
import { theme } from 'assets/styles/theme';

const { Item } = List;
const { Brief } = Item;

const index = ({ show, data, onRequestClose }) => {

  const telTo = (number) => {
    if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'OPEN_URL', url: `tel:${number}` }));
  };

  const phoneAddDash = (number) => {
    switch (true) {
      case number.length === 8:
        return number.replace(/(\d{4})(\d{4})/, '$1-$2');
      case number.length === 9:
        return number.replace(/(\d{2})(\d{3})(\d{4})/, '$1-$2-$3');
      case number.length === 11:
        return number.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
      case number.length === 12:
        return number.replace(/(\d{4})(\d{4})(\d{4})/, '$1-$2-$3');
      default:
        if (number.indexOf('02') === 0 ) {
          return number.replace(/(\d{2})(\d{4})(\d{4})/, '$1-$2-$3');
        }
        return number.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
    };
  };

  const schedule = (events) => {
    let kor;

    let idx = 0;
    const temp = [];

    if (events) {

      for (let i = idx; i < events.length; i++) {
        for (let j = 0; j < 7; j++) {
          if (events[i].day_of_week === j) {
            temp.push([]);
            temp[j] = ({
              day_of_week: events[i].day_of_week,
              start_time: events[i].start_time,
              end_time: events[i].end_time
            });
            idx++;
            break;
          } else if (!temp[j]) {
            temp.push([]);
            temp[j] = ({
              day_of_week: j,
              off_day: '휴무일'
            });
          }
        }
      }

      for (let k = 0; k < 7; k++) {
        if (!temp[k] && temp[k] !== 0) {
          temp[k] = ({
            day_of_week: k,
            off_day: '휴무일'
          });
        }
      }

      // 일요일(temp[0]) 마지막 인덱스로
      temp.splice(7, 0, temp[0]);
      temp.shift();

      
      // 한글 변환
      return temp.map((e, count) => {

        if (count < 7) {

          switch (e.day_of_week) {
            case 0: kor = '일'; break;
            case 1: kor = '월'; break;
            case 2: kor = '화'; break;
            case 3: kor = '수'; break;
            case 4: kor = '목'; break;
            case 5: kor = '금'; break;
            case 6: kor = '토'; break;
          }

          return (
            // eslint-disable-next-line react/no-array-index-key
            <div key={count} className='address gap'>
              <span className='day'>{kor}</span>
              {e?.start_time ? <span>{e?.start_time?.slice(0, -3)}~{e?.end_time?.slice(0, -3)}</span> : <span>{e.off_day}</span>}
            </div>
          );
        }

      });

    }

  };


  return (
    <div className={`react-actionsheet${show ? ' react-actionsheet-show' : ''}`}>
      <div className="react-actionsheet-mask" onClick={onRequestClose} />
      <div className="react-actionsheet-wrap">

        <ContainerStyle>
          <ListStyle>
            <List>
              <Item>
                {/* 닫기 버튼 */}
                <Close className='close_icon' onClick={onRequestClose} />

                {/* 시설정보 */}
                <Brief><div className='info'>시설 정보</div></Brief>

                {/* 연락처 */}
                <Brief><div className='title'><Studio />상호명</div></Brief>
                {/* 이름 */}
                <Brief><div className='name'>{data?.name}</div></Brief>
              </Item>

              <div className='contact'>
                <Item>
                  {/* 연락처 */}
                  <Brief><div className='title'><Phone />연락처</div></Brief>

                  {/* 전화걸기 */}
                  {data?.contactInfos.map((number) => {
                    if (number?.type?.type === 'telephone' || number?.type?.type === 'cellphone') {
                      return (
                        <Brief key={number.id}><div className='phone'><span>{phoneAddDash(number?.contact)}</span><span onClick={() => telTo(number.contact)}><Call /></span></div></Brief>
                      );
                    }
                })}
                </Item>
              </div>

              {(data?.address?.address || data?.address?.detail_address) && (
                <Item>
                  {/* 주소 */}
                  <Brief><div className='title'><Address />주소</div></Brief>

                  {/* 스튜디오 주소 */}
                  <Brief><div className='address'>{data?.address?.address} {data?.address?.detail_address}</div></Brief>
                </Item>
              )}

              <Item>
                {/* 영업시간 */}
                <Brief><div className='title'><Schedule />영업시간</div></Brief>

                {/* 스케쥴 */}
                <Brief>{schedule(data?.openEvents)}</Brief>
              </Item>

            </List>
          </ListStyle>
        </ContainerStyle>
      </div>
    </div>
  );

};

const ContainerStyle = styled.div`
  padding: 0 16px 5px 2px;
  overflow-y: scroll;
`;

const ListStyle = styled.div`
  .am-list-body::before, .am-list-body::after {
    background-color: white !important;
  }
  .am-list-body .am-list-item .am-list-line .am-list-content {
    padding: 16px 0;
  }
  .info {
    margin-bottom: 16px;
    font-size: 14px;
    font-weight: normal;
    line-height: normal;
    color: ${theme.color.black500};
  }
  .name {
    font-size: 16px;
    font-weight: 500;
    line-height: normal;
    color: ${theme.color.black500};
    white-space: break-spaces;
  }
  .title {
    margin-bottom: 16px;
    display: flex;
    font-size: 16px;
    font-weight: normal;
    line-height: normal;
    color: #646464;

    svg {
      margin-right: 4px;
    }
  }
  .phone {
    margin-bottom: 15px;
    display: flex;
    font-size: 18px;
    font-weight: bold;
    line-height: normal;
    color: ${theme.color.black000};

    svg {
      font-weight: normal;
      position: absolute;
      right: 0;
    }
  }
  .address {
    font-size: 18px;
    font-weight: normal;
    line-height: 1.5;
    color: ${theme.color.black000};
    white-space: break-spaces;
  }
  .day {
    margin: 0 8px 0 4px;
  }
  .gap {
    margin-bottom: 8px;
  }
  .contact {
    .am-list-content {
      padding: 16px 0 1px 0 !important;
    }
  }
`;


export default index;
