import React from 'react';
import styled, { css } from 'styled-components';

import MainLayout from 'components/MainLayout';
import { selectStudioProps } from 'pages/SelectStudio/type';
import { _ } from 'utils/fx';
import filters from 'utils/filters';

import { deleteToken } from 'store/auth/actions';
import { HEADER_TITLE, ERROR_TYPES } from 'constants/text';
import Ad from 'components/Ad';
import NoSelectionBox from 'components/NoSelectionBox';

type studioCardProps = {
  selected: { id: number };
  studioId: number;
};

const SelectStudio = ({ loading, companies, currentStudioData, setStudio }: selectStudioProps) => {

  const phone = (contactInfos: { contact: string; is_representative: boolean }[]): string | null => {
    if (contactInfos.length) {
      return _.go(
        contactInfos,
        _.filter((u: { is_representative: boolean }) => u.is_representative),
        _.map(({ contact }: { contact: string }) => contact),
        ([contact]: string[]) => contact,
        (result: string) => filters.phoneFomatter(result),
      );
    } return null;
  };

  const backFunc = () => {
    // dispatch(deleteToken());
    // history.push({
    //   pathname: '/login',
    // });

    return null;
  };


  return (
    <MainLayout header={{ title: HEADER_TITLE.selectStudio, titleNormal: true, noLeftIcon: true, backFunc }} contentsGrid loading={loading}>
      <ContainerStyle>
        {!loading
            ? 
            companies.length !== 0 ?
              companies.map(({ studio }) => {
                  return (
                    <StudioCard
                      selected={currentStudioData.studio}
                      studioId={studio.id}
                      role="button"
                      tabIndex={0}
                      key={studio.id}
                      onClick={() => setStudio(studio)}>
                      {/* <p>{studio.id}</p> */}
                      <div className="title-name">{studio.name}</div>
                      <div className="content">{phone(studio.contactInfos)}</div>
                      <div className="content">
                        {studio.address.address} {studio.address.detail_address}
                      </div>
                    </StudioCard>
                  );
                })
                : (
                  <NoSelectionBox text={ERROR_TYPES.noStudio} />
              )
            : null }
      </ContainerStyle>

      {/* <Ad /> */}
      
    </MainLayout>
  );
};

const cardStyle = css`
  border-radius: 24px;
  text-align: center;
  padding: 24px;
  width: 100%;
  box-shadow: 2px 2px 8px 0 rgba(0, 0, 0, 0.2), 0 2px 4px 0 rgba(0, 0, 0, 0.5);
  margin-bottom: 24px;
  background-image: linear-gradient(115deg, #3391ed, #9a92f5 100%);
  height: 155px;
  color: white;

  .title-name {
    ${props => props.theme.fonts.font18};
    font-weight: bold;
    margin-bottom: 33px;
  }
  .content {
    font-size: 14px;
    font-weight: 500;
    margin-top: 10px;
  }
`;

const StudioCard = styled.div<studioCardProps>`
  ${cardStyle}

  ${({ selected, studioId }) => {
    if (selected.id === studioId) {
      return css`
        border: solid 2px #ffffff;
      `;
    }
    return css`
      opacity: 0.6;
    `;
  }}
`;

const ContainerStyle = styled.div`
  padding: 24px 16px;
  overflow-y: auto;
`;


export default SelectStudio;
