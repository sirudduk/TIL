import React from 'react';
import styled from 'styled-components';

const Ad = () => {
    return (
      <Container>광고</Container>
    );
};

const Container = styled.div`
    border: solid 1px #979797;
    background-color: #d8d8d8;
    text-align: center;
    width: 100%;
    padding: 20px 0;
    color: #555;
`;

export default Ad;