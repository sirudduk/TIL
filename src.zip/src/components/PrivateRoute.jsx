import React, { useEffect, useRef } from 'react';
import { Route, Redirect, useHistory } from 'react-router-dom';
import { useSelector } from 'react-redux';
import localStorage from 'utils/localStorage';

const PrivateRoute = ({ component: Component, ...rest }) => {
  const history = useHistory();
  const isLogin = useSelector(state => state.auth.isLogin);
  const isLoginRef = useRef(isLogin);

  useEffect(() => {
    isLoginRef.current = isLogin
    
    if (!isLogin) {
      localStorage.remove();
      history.replace('/login');
    }
  }, [isLogin])

  return (
    <Route
      {...rest}
      render={props =>
        localStorage.get('access_token') ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: '/login',
              state: { from: props.location },
            }}
          />
        )
      }
    />
  );
};

export default PrivateRoute;
