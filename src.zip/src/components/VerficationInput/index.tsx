import * as React from 'react';
import './VerficationCss.scss';

const KEY_CODE = {
  BACKSPACE: 8,
  ARROW_LEFT: 37,
  ARROW_RIGHT: 39,
  DELETE: 46,
};

type VerificationInputType = {
  length?: number;
  onChange: (data: string) => any;
  placeholder?: string;
};

const VerificationInput = ({ length = 4, onChange, placeholder = '·' }: VerificationInputType) => {
  const [activeIndex, setActiveIndex] = React.useState<number>(-1);
  const [value, setValue] = React.useState<string[]>(new Array(length).fill(placeholder));
  const [done, setDone] = React.useState<boolean>(false);
  const [infoMsg, setInfoMsg] = React.useState<boolean>(false);

  const codeInputRef = React.createRef<HTMLInputElement>();
  const itemsRef = React.useMemo(() => new Array(length).fill(null).map(() => React.createRef<HTMLDivElement>()), [length]);

  const isCodeRegex = new RegExp(`^[0-9]{${length}}$`);

  const getItem = (index: number) => itemsRef[index]?.current;
  const focusItem = (index: number): void => getItem(index)?.focus();
  const blurItem = (index: number): void => getItem(index)?.blur();

  const onItemFocus = (index: number) => () => {
    setActiveIndex(index);
    if (codeInputRef.current) {
      codeInputRef.current.focus();
      setInfoMsg(true);
    }
  };

  const onInputKeyUp = ({ key, keyCode }: React.KeyboardEvent) => {
    const newValue = [...value];
    const nextIndex = activeIndex + 1;
    const prevIndex = activeIndex - 1;

    const codeInput = codeInputRef.current;
    const currentItem = getItem(activeIndex);

    const isLast = nextIndex === length;
    const isDeleting = keyCode === KEY_CODE.DELETE || keyCode === KEY_CODE.BACKSPACE;

    // keep items focus in sync
    onItemFocus(activeIndex);

    // on delete, replace the current value
    // and focus on the previous item
    if (isDeleting) {
      newValue[activeIndex] = placeholder;
      setValue(newValue);

      if (activeIndex > 0) {
        setActiveIndex(prevIndex);
        focusItem(prevIndex);
      }

      return;
    }

    // if the key pressed is not a number
    // don't do anything
    if (Number.isNaN(+key)) return;

    // reset the current value
    // and set the new one
    if (codeInput) codeInput.value = '';
    newValue[activeIndex] = key;
    setValue(newValue);

    if (!isLast) {
      setActiveIndex(nextIndex);
      focusItem(nextIndex);
      return;
    }

    if (codeInput) codeInput.blur();
    if (currentItem) currentItem.blur();

    setActiveIndex(-1);
  };

  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value: changeValue } = e.target;
    const isCode = isCodeRegex.test(changeValue);

    if (!isCode) return;
    setValue(changeValue.split(''));
    blurItem(activeIndex);
  };

  const onInputBlur = () => {
    if (activeIndex === -1) return;

    blurItem(activeIndex);
    setActiveIndex(-1);
    if (activeIndex === length - 1) {
      setDone(true);
      setInfoMsg(false);
    }
  };

  React.useEffect(() => {
    const codeInput = codeInputRef.current;
    if (!codeInput) return;

    const onPaste = (e: ClipboardEvent) => {
      e.preventDefault();

      const pastedString = e.clipboardData?.getData('text');
      if (!pastedString) return;

      const isNumber = !Number.isNaN(+pastedString);
      if (isNumber) setValue(pastedString.split(''));
    };

    codeInput.addEventListener('paste', onPaste);
    return () => codeInput.removeEventListener('paste', onPaste);
    // eslint-disable-next-line
  }, []);

  React.useEffect(() => {
    onChange(value.join(''));
    // eslint-disable-next-line
  }, [value]);

  return (
    <section>
      <div className="ReactInputVerificationCode__container">
        <input
          ref={codeInputRef}
          autoComplete="one-time-code"
          type="text"
          inputMode="decimal"
          onChange={onInputChange}
          onKeyUp={onInputKeyUp}
          onBlur={onInputBlur}
          className="hide-input"
        />

        {itemsRef.map((ref, i) => (
          <div
            // eslint-disable-next-line react/no-array-index-key
            key={i}
            ref={ref}
            role="button"
            tabIndex={0}
            className={`ReactInputVerificationCode__item ${i < activeIndex || done ? 'is-active' : ''} ${i === activeIndex ? 'now' : ''}`}
            onFocus={onItemFocus(i)}>
            {value[i] || placeholder}
          </div>
        ))}
      </div>
      {infoMsg && <div className="ReactInputVerificationCode__infotxt">카카오톡 또는 문자 메시지로 받은 인증번호 6자리를 입력해주세요.</div>}
    </section>
  );
};

VerificationInput.defaultProps = {
  length: 4,
  placeholder: '·',
};

export default VerificationInput;
