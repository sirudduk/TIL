import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'store';

import MainLayout from 'components/MainLayout';
import UserTicketCard from 'components/UserTicketCard';
import { selectTicketProps } from 'pages/SelectStudio/type';
import { HEADER_TITLE, ERROR_TYPES } from 'constants/text';
import PlainButton from 'components/PlainButton';
import Ad from 'components/Ad';
import NoSelectionBox from 'components/NoSelectionBox';

const SelectTicket = ({ loading, companies, currentStudioData, backToSelectStudio, setTicket, setStudioOnly }: selectTicketProps) => {
  /** hooks */
  const history = useHistory();
  const dispatch = useDispatch();

  /** state */
  const [showPast, setShowPast] = useState(false); 
  const [noTicket, setNoTicket] = useState(false);

  const { data } = useSelector((state: RootState) => state.studio);

  const PreviousTicketBtn = () => {
    return (
      <PreviousBtnStyle>
        <PlainButton color="info" outline onClick={() => history.push('/previous-ticket')}>{HEADER_TITLE.previousTicketBtn}</PlainButton>
      </PreviousBtnStyle>
    );
  };


  useEffect(() => {

    if (companies.length !== 0) {

      // 이전수강권 보여주기 setShowPast
      // 보유한 수강권이 없을경우 setNoTicket
      companies.map(({ studio, ticketCardData }) => { 
        if (studio.id === currentStudioData.studio.id) {
          ticketCardData.map((tickets) => {
            if (!tickets.active || tickets.ticketStatus === '이용만료') {
              setShowPast(true);
              setNoTicket(true);
            } else {
              setNoTicket(false);
            }
          })
        }
      });

    }
  }, []);  

  useEffect(() => {

    // 스튜디오 운영정책 업데이트
    data.map(({ studio }) => {
      if (studio.id === currentStudioData.studio.id) {
        setTimeout(() => {
          setStudioOnly(studio);
        }, 1000); 
        // getUserTicket success 이후 1초 뒤에 실행
      }
    });

  }, [data])
    

  return (
    <MainLayout header={{ title: HEADER_TITLE.selectTicket, titleNormal: true, backFunc: backToSelectStudio, params: null }} contentsGrid loading={loading}>
      <ContainerStyle>

        <div className='studio-name' onClick={() => history.push('/select-ticket')}>{currentStudioData.studio?.name}</div>

        {!loading ?
            companies.length !== 0 ? (

              companies.map(({ studio, ticketCardData, ticket }) => {

                if (studio.id === currentStudioData.studio.id) {
                  return ticketCardData.map((tickets, index) => {

                    if (tickets.active && tickets.ticketStatus !== '이용만료') {

                      return (
                        <div key={tickets.id}>
                          <UserTicketCard onClick={() => setTicket(tickets, ticket[index], tickets.classType === '그룹' ? `/booking-group/${tickets.id}` : `/booking-private/${tickets.id}`)} tickets={tickets} />
                          <TicketDetailStyle>
                            <div>
                              <PlainButton color="primary" outline onClick={() => setTicket(tickets, ticket[index], '/ticket-detail')}>{HEADER_TITLE.ticketDetail}</PlainButton>
                            </div>
                          </TicketDetailStyle>
                        </div>
                      );
                    }
                    
                  });
                }
								return null;
								
              })) : (
                <NoSelectionBox />
            )
            : null}

        {!loading && companies.length !== 0 && noTicket && <NoSelectionBox />}

        {!loading && companies.length !== 0 && showPast && <PreviousTicketBtn />}

      </ContainerStyle>

      {/* <Ad /> */}

    </MainLayout>
  );
};

const TicketDetailStyle = styled.div`
  margin-bottom: 24px;
  text-align: center;
`;

const ContainerStyle = styled.div`
  padding: 16px;
  overflow-y: scroll;

  button {
    font-weight: 500;
    font-size: 18px !important;
    line-height: 1.5;
    max-width: 328px;
  }

  .studio-name {
    text-align: center;
    font-size: 16px;
    font-weight: 500;
    margin-bottom: 24px;
  }
`;

const PreviousBtnStyle = styled.div`
  margin: -15px 0 16px 0;
  text-align: center;
`;

export default SelectTicket;